Thank you for downloading the Surviv Cheat Injector by IceHacks.

## Installation

How to install IceHacks:

1. Extract this `ZIP` file into a folder.
2. Open Chrome\*, and enter "chrome://extensions" in the address bar, or get to extensions via settings.
3. Once you have gotten to extensions, click the button on the top right labeled "developer mode" to turn on Dev Mode.
4. Now on the top left corner, there is a button labeled "load unpacked". Click that and select the folder in which you extracted the Cheat files.
5. You now have the IceHacks cheat! (Or you should). If you want to enable IceHacks for incognito, click on "details", scroll down and select "allow in incognito".

<sup>\* The cheat supports any chromium browser with extension support (this includes: Opera, Chrome, Edge Chromium, Vivaldi, ...).</sup>

If you get any errors while installing make sure to have the right folder selected.

## Minimap Coloration

-   **White Circle**: Tree cache
-   **Blue Circle**: Rock cache
-   **Yellow Box**: SV-98 Container, Storm Bunker
-   **Pink Square**: Hardstone

## Changelog

### v2.0.5

Team joiner! Know when other cheaters are playing, and join their games. Sorry for my slowness on working with this cheat.

-   Fixed
    -   Freeze
    -   Small bugs
    -   Stats page
    -   Downed players on ESP
-   Added
    -   Team joiner
    -   Auto Reload
    -   Auto Heal
    -   Aimbot 2.0
    -   Equip melee option (AutoSwitch)
    -   FollowBot
    -   Chat

### v2.0.5

Freeze fix. Like c'mon surviv... It's time to take down the lights and trees as we are approaching the new year.

-   Fixed
    -   Freeze

### v2.0.5

Christmas update with textures and a theme.

-   Created a `README.md` for the cheat package
-   Fixed
    -   Aim at objects
    -   Aim collisions
    -   SniperSwitch™
    -   Watermarks
    -   Red container disappearing ([#188](https://github.com/IceHacks/SurvivCheatInjector/issues/188))
    -   Reset cheat options ([#189](https://github.com/IceHacks/SurvivCheatInjector/issues/189))
-   Added
    -   Custom textures
    -   Custom theme
    -   SmartSwitch™
    -   Legit mode
    -   Binds ([#171](https://github.com/IceHacks/SurvivCheatInjector/issues/171))
    -   Hardstone block on the minimap ([#190](https://github.com/IceHacks/SurvivCheatInjector/issues/190))
    -   Storm bunker on the minimap
